<?php
$conn = new mysqli("localhost", "root", "");
$conn->select_db("my_db");
session_start();
if (isset($_POST['user'])) {
    $username = $_POST['user'];
    $password = $_POST['pass'];
    $query = $conn->query("select username from admin where username = '$username' and password ='$password'");
    if ($query->num_rows === 1) {
        header("Location: admin.php");
    } else {
        header("Location: logine.html");
    }
}
?>
    